from .continuous_peaks import ContinuousPeaks
from .flip_flop import FlipFlop
from .four_peaks import FourPeaks
from .six_peaks import SixPeaks
from .continuous_peaks import ContinuousPeaks
from .one_max import OneMax
from .max_k_color import MaxKColor
from .knapsack import Knapsack
from .queens import Queens
from .travelling_sales import TravellingSales

from .custom_fitness import CustomFitness
