.. _decay:

Decay Schedules
===============
	
.. automodule:: mlrose.decay
	:member-order: bysource
	:members: