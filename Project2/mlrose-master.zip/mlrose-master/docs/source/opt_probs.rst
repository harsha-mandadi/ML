Optimization Problem Types
==========================

.. automodule:: mlrose.opt_probs

.. autoclass:: DiscreteOpt
.. autoclass:: ContinuousOpt
.. autoclass:: TSPOpt